module Comp1510Lab01DelaCruzG {
}