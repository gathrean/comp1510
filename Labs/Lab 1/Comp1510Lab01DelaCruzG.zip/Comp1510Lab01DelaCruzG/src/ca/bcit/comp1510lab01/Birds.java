package ca.bcit.comp1510lab01;

public class Birds {
    
    public static void main(String[] args) {
        System.out.println("Ten robins plus 13 canaries is " +
                (20+3) + " birds");
    }

}
