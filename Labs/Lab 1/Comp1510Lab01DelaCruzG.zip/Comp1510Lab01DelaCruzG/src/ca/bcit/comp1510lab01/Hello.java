package ca.bcit.comp1510lab01;

/**
 * Prints a Hello World message
 * @author Gathrean Dela Cruz
 * @version 2022
 *
 */

public class Hello {
    
    /**
     * Prints the greeting.
     * @param Args
     *              unused
     */
    
    public static void main (String[] args) {
        System.out.println("Hello world!");
        
    }
/**
 * My answers for Step 4 Question 2 in the Lab Document
 * 
 * a. Error: Could not find or load main class ca.bcit.comp1510lab01.Hello in module Comp1510Lab01DelaCruzG
 * 
 * b. The program ran as usual. 
 * The only difference was that the message in the console says "Helo world!" instead of "Hello world!"
 * 
 * c. Exception in thread "main" java.lang.Error: Unresolved compilation problems: 
    Syntax error on token(s), misplaced construct(s)
    Syntax error, insert "VariableDeclarators" to complete LocalVariableDeclaration
    Syntax error, insert ";" to complete BlockStatements

    at Comp1510Lab01DelaCruzG/ca.bcit.comp1510lab01.Hello.main(Hello.java:19)
 * 
 * d. Exception in thread "main" java.lang.Error: Unresolved compilation problems: 
    Syntax error on token(s), misplaced construct(s)
    Syntax error on token "!", ; expected
    String literal is not properly closed by a double-quote

    at Comp1510Lab01DelaCruzG/ca.bcit.comp1510lab01.Hello.main(Hello.java:19)
 * 
 * e. Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
    Syntax error, insert ";" to complete BlockStatements

    at Comp1510Lab01DelaCruzG/ca.bcit.comp1510lab01.Hello.main(Hello.java:19)
 * 
 */
}


