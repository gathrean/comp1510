package ca.bcit.comp1510lab01;

public class Poem {

    public static void main (String Args[]){
        System.out.println ("Roses are Red");
        System.out.println ("Violets are blue");
        System.out.println ("Sugar is sweet");
        System.out.println ("But I have commitment issues");
        System.out.println ("So I'd rather just be friend");
        System.out.println ("At this point in our relationship");
    }
    
    
    
}
