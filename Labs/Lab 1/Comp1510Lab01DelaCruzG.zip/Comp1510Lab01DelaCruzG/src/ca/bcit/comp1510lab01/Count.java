package ca.bcit.comp1510lab01;


/**
 * 
 * This is a program that counts from 1 to 5 
 * in English, French, and Spanish.
 * 
 * @author Gathrean Dela Cruz
 * @version 2022
 * 
 */

public class Count {

    public static void main (String Args[]) {
        //This print statement counts in English
        System.out.println ("one two three four five");
        
        //This print statement counts in French
        System.out.println ("un deu trois quatre cinq");
        
        //This print statement counts in Spanish
        System.out.println ("uno dos tres cuatro cinco");
    }
}
