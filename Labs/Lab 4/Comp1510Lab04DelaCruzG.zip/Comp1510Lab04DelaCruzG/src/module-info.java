module Comp1510Lab04DelaCruzG {
    requires junit;
    requires org.junit.jupiter.api;
    requires jdk.incubator.vector;
   
requires org.junit.jupiter.params;
}